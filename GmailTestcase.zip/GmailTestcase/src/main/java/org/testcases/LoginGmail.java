package org.testcases;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.pageobjects.LoginpageElements;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class LoginGmail {
	WebDriver driver;
	
	@BeforeTest
	private void launchbrowser() {
		
		 driver = new ChromeDriver();

		 driver.manage().window().maximize();
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		 
	}
	
	
	
	@Test
	private void Login_with_valid_emailandpassword() {
		
		
		
		driver.get("https://accounts.google.com/v3/signin/identifier?elo=1&ifkv=ASKXGp3XvNFZVd4T_13Q_sHX_PlQn-hQqpni27RC5sULDiC-fka8fIXs0Q-TEvCGSZIcLeDm3NvHqQ&theme=glif&flowName=GlifWebSignIn&flowEntry=ServiceLogin&continue\"\r\n"
				+ "				+ \"=https%3A%2F%2Faccounts.google.com%2FManageAccount%3Fnc%3D1");
		
		LoginpageElements loginelements = new LoginpageElements(driver);
		loginelements.enteremail("sathishsambath132@gmail.com");
		
		loginelements.clicknextbtn();
		
		loginelements.enterpassword("password....");

	}
	
	
	
	
	
	

}

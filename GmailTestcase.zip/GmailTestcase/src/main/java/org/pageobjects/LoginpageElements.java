package org.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginpageElements {

	private WebDriver driver;
	// WebElements
    @FindBy(id = "identifierId") public  WebElement emailorphonenumber;
    
    @FindBy(xpath = "//span[text()='Next']")   WebElement nextbtn;
    
    ////input[@type='password']
    @FindBy(xpath = "//input[@type='password']")   WebElement password;
    
    ////span[@data-text='Gmail']
    
    @FindBy(xpath = "//span[@data-text='Gmail']")  WebElement gmailappicon;
    
	//Try again
    
    @FindBy(xpath = "//a[@aria-label='Try again']")   WebElement tryagainbtn;
    
    
    public LoginpageElements(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    
    public void enteremail(String username) {
    	emailorphonenumber.sendKeys(username);

	}
    
    public void enterpassword(String password) {
    	this.password.sendKeys(password);

	}
    
    public void clicknextbtn() {
		nextbtn.click();

	}
    
    public void clicktryagainbtn() {
    	tryagainbtn.click();

	}
    
    
}

package org.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomepageElements {
	//https://accounts.google.com/v3/signin/identifier?hl=en-gb&ifkv=ATuJsjyUdGn-zTHWJ-7K1RFM9jIoYsJAztHY4v4dQg8qp5DSsjk6U8Ox3VqgQsEZ7SqD-wpPFyG74A&flowName=GlifWebSignIn
	//&flowEntry=ServiceLogin&dsh=S-1979025818%3A1707726663350740&theme=glif
	
	
	private WebDriver driver;
	// WebElements
    @FindBy(xpath = "//div[text()='Compose']")  WebElement composebtn;
    
    
   // WebElement uname = .findElement(By.id("vjhv"));

    @FindBy(xpath = "//span[text()='New Message']") private WebElement newmessagepopup;

    @FindBy(xpath = "//input[@aria-label='To recipients']")
    private WebElement totxtbox;
    
    @FindBy(xpath = "(//span[@role='link'])[3]")
    private WebElement ccbtn;
    
    
    @FindBy(xpath = "(//span[@role='link'])[4]")
    private WebElement bccbtn;
    
    @FindBy(xpath = "//input[@aria-label='BCC recipients']")
    private WebElement cctxtbox;
    
    

    // WebDriver instance
    

    // Constructor
    public HomepageElements(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Page methods
    public void enterUsername(String username) {
        usernameInput.sendKeys(username);
    }

    public void enterPassword(String password) {
        passwordInput.sendKeys(password);
    }

    public void clickLoginButton() {
        loginButton.click();
    }


}
